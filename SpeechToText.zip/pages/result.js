import React from 'react'
import Results from '../components/Result'


const Result = () => {
    return <div>
        <Results/>
        
    </div>
  }
  
  export default Result
import React from 'react'

const Price = () => {
    return <div>
      price
    </div>
  }
  
  export default Price
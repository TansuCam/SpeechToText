

const Result = () =>{
    return(
        <div className="container">
        <div className="row" style={{marginTop: 100}}>
            <div className="col-lg-8">
                <div className="card">
                    <h3 className="card-header text-center font-weight-bold text-uppercase py-4">İŞLEM TAMAMLANDI</h3>
                    <div className="card-body">
                        <p>Text</p>
                       
                        <button  className="btn btn-info btn-block"  style={{textDecoration: "none", color:"white"}}>Onayla</button>
                 
                    </div>
                </div>
            </div></div></div>

    )}
export default Result